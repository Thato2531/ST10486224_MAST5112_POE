import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './src/HomeScreen';
import AddMenuScreen from './src/AddMenuScreen';
import MenuListScreen from './src/MenuListScreen';
import FilterScreen from './src/FilterScreen';
import { RootStackParamList } from './src/types';

const Stack = createStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        initialRouteName="Home"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#2563eb',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          cardStyle: {
            flex: 1,
            backgroundColor: '#f8fafc',
          }
        }}
      >
        <Stack.Screen 
          name="Home" 
          component={HomeScreen} 
          options={{ 
            title: 'Chef Menu',
            headerShown: false
          }} 
        />
        <Stack.Screen 
          name="AddMenu" 
          component={AddMenuScreen} 
          options={{ 
            title: 'Add to Menu' 
          }} 
        />
        <Stack.Screen 
          name="MenuList" 
          component={MenuListScreen} 
          options={{ 
            title: 'Menu List' 
          }} 
        />
        <Stack.Screen 
          name="Filter" 
          component={FilterScreen} 
          options={{ 
            title: 'Search Menu' 
          }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
