import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, TextInput } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, MenuItem } from './types';

type AddMenuScreenNavigationProp = StackNavigationProp<RootStackParamList, 'AddMenu'>;

interface Props {
  navigation: AddMenuScreenNavigationProp;
}

const availableItems: MenuItem[] = [
  { id: '1', name: 'Garlic Bread', price: 45, description: 'Fresh baked bread with garlic butter', category: 'starter' },
  { id: '2', name: 'Caesar Salad', price: 85, description: 'Crisp romaine with caesar dressing', category: 'starter' },
  { id: '3', name: 'Soup of the Day', price: 65, description: 'Chef\'s daily special soup', category: 'starter' },
  { id: '4', name: 'Grilled Steak', price: 220, description: 'Premium beef steak with vegetables', category: 'main' },
  { id: '5', name: 'Chicken Alfredo', price: 180, description: 'Creamy pasta with grilled chicken', category: 'main' },
  { id: '6', name: 'Seafood Platter', price: 280, description: 'Fresh fish, calamari, and prawns', category: 'main' },
  { id: '7', name: 'Chocolate Cake', price: 75, description: 'Rich chocolate layered cake', category: 'dessert' },
  { id: '8', name: 'Ice Cream Sundae', price: 60, description: 'Vanilla ice cream with toppings', category: 'dessert' },
  { id: '9', name: 'Fruit Platter', price: 55, description: 'Seasonal fresh fruits', category: 'dessert' },
];

const AddMenuScreen: React.FC<Props> = ({ navigation }) => {
  const [selectedItems, setSelectedItems] = useState<MenuItem[]>([]);
  const [newItem, setNewItem] = useState({ 
    name: '', 
    price: '', 
    description: '',
    category: 'main' as 'starter' | 'main' | 'dessert'
  });

  const total = selectedItems.reduce((sum, item) => sum + item.price, 0);

  const starters = availableItems.filter(item => item.category === 'starter');
  const mains = availableItems.filter(item => item.category === 'main');
  const desserts = availableItems.filter(item => item.category === 'dessert');

  const toggleItemSelection = (item: MenuItem) => {
    const categoryCount = selectedItems.filter(selected => selected.category === item.category).length;
    
    if (selectedItems.some(selected => selected.id === item.id)) {
      setSelectedItems(prev => prev.filter(selected => selected.id !== item.id));
    } else {
      if (categoryCount >= 3) {
        Alert.alert('Limit Reached', `You can only select 3 ${item.category}s`);
        return;
      }
      setSelectedItems(prev => [...prev, item]);
    }
  };

  const addCustomItem = () => {
    if (newItem.name && newItem.price && newItem.description) {
      const customItem: MenuItem = {
        id: `custom-${Date.now()}`,
        name: newItem.name,
        price: parseFloat(newItem.price) || 0,
        description: newItem.description,
        category: newItem.category
      };
      
      const categoryCount = selectedItems.filter(item => item.category === newItem.category).length;
      if (categoryCount >= 3) {
        Alert.alert('Limit Reached', `You can only select 3 ${newItem.category}s`);
        return;
      }
      
      setSelectedItems(prev => [...prev, customItem]);
      setNewItem({ 
        name: '', 
        price: '', 
        description: '', 
        category: 'main'
      });
      Alert.alert('Success', 'Custom item added to your order!');
    } else {
      Alert.alert('Error', 'Please fill in all fields');
    }
  };

  const isItemSelected = (item: MenuItem) => {
    return selectedItems.some(selected => selected.id === item.id);
  };

  const getCategoryCount = (category: string) => {
    return selectedItems.filter(item => item.category === category).length;
  };

  const renderCategorySection = (title: string, items: MenuItem[], category: string) => (
    <View style={styles.categorySection}>
      <View style={styles.categoryHeader}>
        <Text style={styles.categoryTitle}>{title}</Text>
        <View style={styles.categoryInfo}>
          <Text style={styles.categoryLimit}>(Select up to 3)</Text>
          <Text style={styles.selectedCount}>{getCategoryCount(category)}/3 selected</Text>
        </View>
      </View>
      {items.map((item) => (
        <TouchableOpacity
          key={item.id}
          style={[
            styles.itemCard,
            isItemSelected(item) && styles.selectedItem
          ]}
          onPress={() => toggleItemSelection(item)}
        >
          <View style={styles.itemContent}>
            <View style={styles.itemMain}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>R{item.price}</Text>
            </View>
            <Text style={styles.itemDescription}>{item.description}</Text>
          </View>
          {isItemSelected(item) && (
            <View style={styles.selectedIndicator}>
              <Text style={styles.selectedBadge}>✓ SELECTED</Text>
            </View>
          )}
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={true}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Create Your Order</Text>
        <Text style={styles.subtitle}>Select items or create custom dishes</Text>
      </View>

      <View style={styles.customSection}>
        <Text style={styles.sectionTitle}>➕ Add Custom Item</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Dish Name"
          placeholderTextColor="#94a3b8"
          value={newItem.name}
          onChangeText={(text) => setNewItem(prev => ({ ...prev, name: text }))}
        />
        
        <TextInput
          style={styles.input}
          placeholder="Price"
          placeholderTextColor="#94a3b8"
          keyboardType="numeric"
          value={newItem.price}
          onChangeText={(text) => setNewItem(prev => ({ ...prev, price: text }))}
        />
        
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Description"
          placeholderTextColor="#94a3b8"
          multiline
          numberOfLines={3}
          value={newItem.description}
          onChangeText={(text) => setNewItem(prev => ({ ...prev, description: text }))}
        />
        
        <View style={styles.categorySelector}>
          <Text style={styles.selectorLabel}>Category:</Text>
          <View style={styles.selectorButtons}>
            <TouchableOpacity
              style={[
                styles.categoryButton,
                newItem.category === 'starter' && styles.categoryButtonSelected
              ]}
              onPress={() => setNewItem(prev => ({ ...prev, category: 'starter' }))}
            >
              <Text style={[
                styles.categoryButtonText,
                newItem.category === 'starter' && styles.categoryButtonTextSelected
              ]}>Starter</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.categoryButton,
                newItem.category === 'main' && styles.categoryButtonSelected
              ]}
              onPress={() => setNewItem(prev => ({ ...prev, category: 'main' }))}
            >
              <Text style={[
                styles.categoryButtonText,
                newItem.category === 'main' && styles.categoryButtonTextSelected
              ]}>Main Course</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.categoryButton,
                newItem.category === 'dessert' && styles.categoryButtonSelected
              ]}
              onPress={() => setNewItem(prev => ({ ...prev, category: 'dessert' }))}
            >
              <Text style={[
                styles.categoryButtonText,
                newItem.category === 'dessert' && styles.categoryButtonTextSelected
              ]}>Dessert</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <TouchableOpacity style={styles.addButton} onPress={addCustomItem}>
          <Text style={styles.addButtonText}>➕ ADD CUSTOM ITEM</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.menuSection}>
        <Text style={styles.sectionTitle}>📋 Menu Items</Text>
        <Text style={styles.sectionSubtitle}>Choose from our menu (up to 3 per category)</Text>

        {renderCategorySection('🥗 STARTERS', starters, 'starter')}
        {renderCategorySection('🍖 MAIN COURSES', mains, 'main')}
        {renderCategorySection('🍰 DESSERTS', desserts, 'dessert')}
      </View>

      <View style={styles.totalSection}>
        <Text style={styles.totalLabel}>Order Total</Text>
        <Text style={styles.totalAmount}>R{total.toFixed(2)}</Text>
        <Text style={styles.itemCount}>{selectedItems.length} items selected</Text>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backButtonText}>← BACK</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.nextButton, selectedItems.length === 0 && styles.disabledButton]} 
          onPress={() => {
            if (selectedItems.length > 0) {
              navigation.navigate('MenuList', { selectedItems });
            }
          }}
          disabled={selectedItems.length === 0}
        >
          <Text style={styles.nextButtonText}>
            {selectedItems.length > 0 ? 'REVIEW ORDER →' : 'SELECT ITEMS'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 30,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  customSection: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },
  menuSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 10,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
    fontSize: 16,
    backgroundColor: '#f8fafc',
    color: '#1e293b',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  categorySelector: {
    marginBottom: 16,
  },
  selectorLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#1e293b',
  },
  selectorButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  categoryButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
    alignItems: 'center',
    marginHorizontal: 4,
  },
  categoryButtonSelected: {
    backgroundColor: '#3b82f6',
  },
  categoryButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#64748b',
  },
  categoryButtonTextSelected: {
    color: 'white',
  },
  addButton: {
    backgroundColor: '#10b981',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  categorySection: {
    marginBottom: 20,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryInfo: {
    alignItems: 'flex-end',
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  categoryLimit: {
    fontSize: 12,
    color: '#64748b',
  },
  selectedCount: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#10b981',
  },
  itemCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 2,
    borderColor: '#f1f5f9',
    overflow: 'hidden',
  },
  selectedItem: {
    borderColor: '#3b82f6',
    backgroundColor: '#f0f9ff',
  },
  itemContent: {
    padding: 16,
  },
  itemMain: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1,
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  itemDescription: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  selectedIndicator: {
    backgroundColor: '#3b82f6',
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  selectedBadge: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  totalSection: {
    backgroundColor: 'white',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  totalLabel: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 8,
  },
  totalAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 4,
  },
  itemCount: {
    fontSize: 14,
    color: '#94a3b8',
  },
  buttonContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  backButton: {
    flex: 1,
    backgroundColor: '#64748b',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginRight: 8,
  },
  backButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  nextButton: {
    flex: 2,
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginLeft: 8,
  },
  disabledButton: {
    backgroundColor: '#cbd5e1',
  },
  nextButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AddMenuScreen;