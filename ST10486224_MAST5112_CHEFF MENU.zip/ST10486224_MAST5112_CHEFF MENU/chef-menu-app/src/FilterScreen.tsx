import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList, MenuItem } from './types';

type FilterScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Filter'>;
type FilterScreenRouteProp = RouteProp<RootStackParamList, 'Filter'>;

interface Props {
  navigation: FilterScreenNavigationProp;
  route: FilterScreenRouteProp;
}

const allMenuItems: MenuItem[] = [
  { id: '1', name: 'Garlic Bread', price: 45, description: 'Fresh baked bread with garlic butter', category: 'starter' },
  { id: '2', name: 'Caesar Salad', price: 85, description: 'Crisp romaine with caesar dressing', category: 'starter' },
  { id: '3', name: 'Soup of the Day', price: 65, description: 'Chef\'s daily special soup', category: 'starter' },
  { id: '4', name: 'Grilled Steak', price: 220, description: 'Premium beef steak with vegetables', category: 'main' },
  { id: '5', name: 'Chicken Alfredo', price: 180, description: 'Creamy pasta with grilled chicken', category: 'main' },
  { id: '6', name: 'Seafood Platter', price: 280, description: 'Fresh fish, calamari, and prawns', category: 'main' },
  { id: '7', name: 'Chocolate Cake', price: 75, description: 'Rich chocolate layered cake', category: 'dessert' },
  { id: '8', name: 'Ice Cream Sundae', price: 60, description: 'Vanilla ice cream with toppings', category: 'dessert' },
  { id: '9', name: 'Fruit Platter', price: 55, description: 'Seasonal fresh fruits', category: 'dessert' },
];

const FilterScreen: React.FC<Props> = ({ navigation, route }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'starter' | 'main' | 'dessert'>('all');
  const [filteredItems, setFilteredItems] = useState<MenuItem[]>(allMenuItems);

  useEffect(() => {
    let results = allMenuItems;

    if (searchQuery) {
      results = results.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      results = results.filter(item => item.category === selectedCategory);
    }

    setFilteredItems(results);
  }, [searchQuery, selectedCategory]);

  const categories = [
    { key: 'all', label: 'ALL ITEMS', icon: '🍽️' },
    { key: 'starter', label: 'STARTERS', icon: '🥗' },
    { key: 'main', label: 'MAIN COURSES', icon: '🍖' },
    { key: 'dessert', label: 'DESSERTS', icon: '🍰' },
  ];

  const getCategoryColor = (category: string) => {
    switch(category) {
      case 'starter': return '#10b981';
      case 'main': return '#ef4444';
      case 'dessert': return '#f59e0b';
      default: return '#3b82f6';
    }
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={true}
    >
      <View style={styles.header}>
        <Text style={styles.title}>🔍 Search Menu</Text>
        <Text style={styles.subtitle}>Find your favorite dishes</Text>
      </View>

      <View style={styles.searchSection}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search dishes by name or description..."
          placeholderTextColor="#94a3b8"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <Text style={styles.sectionTitle}>Filter by Category</Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.categoryContainer}
        contentContainerStyle={styles.categoryContent}
      >
        {categories.map((category) => (
          <TouchableOpacity
            key={category.key}
            style={[
              styles.categoryButton,
              selectedCategory === category.key && styles.categoryButtonSelected
            ]}
            onPress={() => setSelectedCategory(category.key as any)}
          >
            <Text style={styles.categoryIcon}>{category.icon}</Text>
            <Text style={[
              styles.categoryButtonText,
              selectedCategory === category.key && styles.categoryButtonTextSelected
            ]}>
              {category.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.resultsHeader}>
        <Text style={styles.resultsCount}>
          {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'} found
        </Text>
        {(searchQuery || selectedCategory !== 'all') && (
          <TouchableOpacity 
            style={styles.clearButton}
            onPress={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
          >
            <Text style={styles.clearButtonText}>Clear filters</Text>
          </TouchableOpacity>
        )}
      </View>

      {filteredItems.length === 0 ? (
        <View style={styles.noResults}>
          <Text style={styles.noResultsIcon}>🔍</Text>
          <Text style={styles.noResultsText}>No dishes found</Text>
          <Text style={styles.noResultsSubtext}>Try adjusting your search or filters</Text>
        </View>
      ) : (
        <View style={styles.resultsSection}>
          {filteredItems.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.menuItem}
              onPress={() => {
                navigation.navigate('AddMenu');
              }}
            >
              <View style={styles.itemHeader}>
                <Text style={styles.dishName}>{item.name}</Text>
                <Text style={styles.price}>R{item.price}</Text>
              </View>
              <View style={[styles.categoryTag, { backgroundColor: getCategoryColor(item.category) }]}>
                <Text style={styles.categoryTagText}>
                  {item.category.toUpperCase()}
                </Text>
              </View>
              <Text style={styles.description}>{item.description}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <TouchableOpacity 
        style={styles.backButton} 
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>← BACK TO MENU</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 30,
  },
  header: {
    alignItems: 'center',
    marginBottom: 25,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  searchSection: {
    marginBottom: 20,
  },
  searchInput: {
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#1e293b',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#1e293b',
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryContent: {
    paddingRight: 16,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 25,
    backgroundColor: '#f1f5f9',
    marginRight: 10,
    minWidth: 120,
  },
  categoryButtonSelected: {
    backgroundColor: '#3b82f6',
  },
  categoryIcon: {
    fontSize: 16,
    marginRight: 6,
  },
  categoryButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#64748b',
  },
  categoryButtonTextSelected: {
    color: 'white',
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultsCount: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '600',
  },
  clearButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#ef4444',
    borderRadius: 8,
  },
  clearButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  noResults: {
    backgroundColor: 'white',
    padding: 40,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  noResultsIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  noResultsText: {
    fontSize: 18,
    color: '#1e293b',
    marginBottom: 8,
    fontWeight: '600',
  },
  noResultsSubtext: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  resultsSection: {
    marginBottom: 20,
  },
  menuItem: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#3b82f6',
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  dishName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1,
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  categoryTag: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginBottom: 8,
  },
  categoryTagText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  description: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  backButton: {
    backgroundColor: '#64748b',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  backButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default FilterScreen;