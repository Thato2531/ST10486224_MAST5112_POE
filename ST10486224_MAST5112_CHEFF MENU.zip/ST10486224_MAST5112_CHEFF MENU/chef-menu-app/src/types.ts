export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  category: 'starter' | 'main' | 'dessert';
}

export type RootStackParamList = {
  Home: undefined;
  AddMenu: undefined;
  MenuList: { selectedItems: MenuItem[] };
  Filter: undefined;
};