import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList, MenuItem } from './types';

type MenuListScreenNavigationProp = StackNavigationProp<RootStackParamList, 'MenuList'>;
type MenuListScreenRouteProp = RouteProp<RootStackParamList, 'MenuList'>;

interface Props {
  navigation: MenuListScreenNavigationProp;
  route: MenuListScreenRouteProp;
}

const MenuListScreen: React.FC<Props> = ({ navigation, route }) => {
  const selectedItems = route.params?.selectedItems || [];

  const total = selectedItems.reduce((sum, item) => sum + item.price, 0);

  const handleProceed = () => {
    Alert.alert(
      '🎉 Order Confirmed!',
      `Your order total is R${total.toFixed(2)}. Thank you for dining with us!`,
      [{ text: 'OK', onPress: () => navigation.navigate('Home') }]
    );
  };

  const groupItemsByCategory = (items: MenuItem[]) => {
    const grouped: { [key: string]: MenuItem[] } = {
      starter: [],
      main: [],
      dessert: []
    };
    
    items.forEach(item => {
      grouped[item.category].push(item);
    });
    
    return grouped;
  };

  const groupedItems = groupItemsByCategory(selectedItems);

  const getCategoryTitle = (category: string) => {
    switch(category) {
      case 'starter': return '🥗 STARTERS';
      case 'main': return '🍖 MAIN COURSES';
      case 'dessert': return '🍰 DESSERTS';
      default: return category.toUpperCase();
    }
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={true}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Your Order Summary</Text>
        <Text style={styles.subtitle}>Review your selected items</Text>
      </View>

      {selectedItems.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateIcon}>🛒</Text>
          <Text style={styles.emptyStateText}>Your cart is empty</Text>
          <Text style={styles.emptyStateSubtext}>Add some delicious items to get started</Text>
          <TouchableOpacity
            style={styles.addItemsButton}
            onPress={() => navigation.navigate('AddMenu')}
          >
            <Text style={styles.addItemsButtonText}>➕ ADD ITEMS</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {Object.entries(groupedItems).map(([category, items]) => 
            items.length > 0 && (
              <View key={category} style={styles.categorySection}>
                <View style={styles.categoryHeader}>
                  <Text style={styles.categoryTitle}>{getCategoryTitle(category)}</Text>
                  <View style={styles.categoryCount}>
                    <Text style={styles.categoryCountText}>{items.length} items</Text>
                  </View>
                </View>
                {items.map((item) => (
                  <View key={item.id} style={styles.menuItem}>
                    <View style={styles.itemMain}>
                      <Text style={styles.dishName}>{item.name}</Text>
                      <Text style={styles.itemPrice}>R{item.price}</Text>
                    </View>
                    <Text style={styles.description}>{item.description}</Text>
                    {item.id.includes('custom') && (
                      <View style={styles.customBadge}>
                        <Text style={styles.customBadgeText}>Custom Item</Text>
                      </View>
                    )}
                  </View>
                ))}
              </View>
            )
          )}

          <View style={styles.totalSection}>
            <View style={styles.totalHeader}>
              <Text style={styles.totalLabel}>Order Total</Text>
              <Text style={styles.totalAmount}>R{total.toFixed(2)}</Text>
            </View>
            <Text style={styles.itemCount}>{selectedItems.length} items in total</Text>
            <View style={styles.totalDivider} />
            <Text style={styles.thankYouText}>Thank you for your order! 🎉</Text>
          </View>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.backButtonText}>← EDIT ORDER</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.proceedButton}
              onPress={handleProceed}
            >
              <Text style={styles.proceedButtonText}>CONFIRM ORDER →</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 30,
  },
  header: {
    alignItems: 'center',
    marginBottom: 25,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  categorySection: {
    marginBottom: 25,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 12,
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
    flex: 1,
  },
  categoryCount: {
    backgroundColor: '#dbeafe',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryCountText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  menuItem: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#3b82f6',
  },
  itemMain: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  dishName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1,
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  description: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 8,
    lineHeight: 20,
  },
  customBadge: {
    backgroundColor: '#10b981',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  customBadgeText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  totalSection: {
    backgroundColor: 'white',
    padding: 24,
    borderRadius: 16,
    marginBottom: 20,
  },
  totalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e293b',
  },
  totalAmount: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  itemCount: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 12,
  },
  totalDivider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    marginVertical: 12,
  },
  thankYouText: {
    fontSize: 14,
    color: '#10b981',
    fontWeight: '600',
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  backButton: {
    flex: 1,
    backgroundColor: '#64748b',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginRight: 8,
  },
  backButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  proceedButton: {
    flex: 2,
    backgroundColor: '#10b981',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginLeft: 8,
  },
  proceedButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyState: {
    backgroundColor: 'white',
    padding: 40,
    borderRadius: 16,
    alignItems: 'center',
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyStateText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 20,
  },
  addItemsButton: {
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  addItemsButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default MenuListScreen;