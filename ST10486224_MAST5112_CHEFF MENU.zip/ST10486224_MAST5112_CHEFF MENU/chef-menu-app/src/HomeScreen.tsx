import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, MenuItem } from './types';

type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Home'>;

interface Props {
  navigation: HomeScreenNavigationProp;
}

const sampleMenu: MenuItem[] = [
  { id: '1', name: 'Garlic Bread', price: 45, description: 'Fresh baked bread with garlic butter', category: 'starter' },
  { id: '2', name: 'Caesar Salad', price: 85, description: 'Crisp romaine with caesar dressing', category: 'starter' },
  { id: '3', name: 'Soup of the Day', price: 65, description: 'Chef\'s daily special soup', category: 'starter' },
  { id: '4', name: 'Grilled Steak', price: 220, description: 'Premium beef steak with vegetables', category: 'main' },
  { id: '5', name: 'Chicken Alfredo', price: 180, description: 'Creamy pasta with grilled chicken', category: 'main' },
  { id: '6', name: 'Seafood Platter', price: 280, description: 'Fresh fish, calamari, and prawns', category: 'main' },
  { id: '7', name: 'Chocolate Cake', price: 75, description: 'Rich chocolate layered cake', category: 'dessert' },
  { id: '8', name: 'Ice Cream Sundae', price: 60, description: 'Vanilla ice cream with toppings', category: 'dessert' },
  { id: '9', name: 'Fruit Platter', price: 55, description: 'Seasonal fresh fruits', category: 'dessert' },
];

const HomeScreen: React.FC<Props> = ({ navigation }) => {
  const starters = sampleMenu.filter(item => item.category === 'starter');
  const mains = sampleMenu.filter(item => item.category === 'main');
  const desserts = sampleMenu.filter(item => item.category === 'dessert');

  const renderMenuSection = (title: string, items: MenuItem[]) => (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <View style={styles.sectionLine} />
      </View>
      {items.map((item) => (
        <View key={item.id} style={styles.menuItem}>
          <View style={styles.itemHeader}>
            <Text style={styles.dishName}>{item.name}</Text>
            <View style={styles.priceBadge}>
              <Text style={styles.price}>R{item.price}</Text>
            </View>
          </View>
          <Text style={styles.description}>{item.description}</Text>
        </View>
      ))}
    </View>
  );

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={true}
    >
      <View style={styles.header}>
        <View style={styles.logo}>
          <Text style={styles.logoIcon}>🍽️</Text>
          <Text style={styles.logoText}>CHRISTOFFEL'S</Text>
          <Text style={styles.logoSubtext}>RESTAURANT</Text>
        </View>
        <Text style={styles.welcomeText}>Discover Our Culinary Excellence</Text>
      </View>

      <View style={styles.quickActions}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.searchButton]} 
          onPress={() => navigation.navigate('Filter')}
        >
          <Text style={styles.actionButtonIcon}>🔍</Text>
          <Text style={styles.actionButtonText}>Search Menu</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.actionButton, styles.orderButton]} 
          onPress={() => navigation.navigate('AddMenu')}
        >
          <Text style={styles.actionButtonIcon}>📝</Text>
          <Text style={styles.actionButtonText}>Create Order</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.menuTitle}>Our Menu</Text>

      {renderMenuSection('STARTERS', starters)}
      {renderMenuSection('MAIN COURSES', mains)}
      {renderMenuSection('DESSERTS', desserts)}

      <View style={styles.bottomNav}>
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('AddMenu')}
        >
          <Text style={styles.navButtonText}>Start Order</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.navButtonSecondary} 
          onPress={() => navigation.navigate('MenuList', { selectedItems: [] })}
        >
          <Text style={styles.navButtonTextSecondary}>View Cart</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 30,
  },
  header: {
    alignItems: 'center',
    marginBottom: 25,
  },
  logo: {
    alignItems: 'center',
    marginBottom: 10,
  },
  logoIcon: {
    fontSize: 40,
    marginBottom: 5,
  },
  logoText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e40af',
    letterSpacing: 1,
  },
  logoSubtext: {
    fontSize: 14,
    color: '#64748b',
    fontWeight: '500',
  },
  welcomeText: {
    fontSize: 16,
    color: '#475569',
    textAlign: 'center',
    marginTop: 5,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 25,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 12,
    marginHorizontal: 5,
  },
  searchButton: {
    backgroundColor: '#3b82f6',
  },
  orderButton: {
    backgroundColor: '#1e40af',
  },
  actionButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  menuTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 20,
    textAlign: 'center',
  },
  section: {
    marginBottom: 25,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
    marginRight: 10,
  },
  sectionLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#dbeafe',
    borderRadius: 1,
  },
  menuItem: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#3b82f6',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  dishName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1e293b',
    flex: 1,
  },
  priceBadge: {
    backgroundColor: '#dbeafe',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  price: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
  },
  description: {
    fontSize: 14,
    color: '#64748b',
    lineHeight: 20,
  },
  bottomNav: {
    marginTop: 10,
  },
  navButton: {
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  navButtonSecondary: {
    backgroundColor: 'transparent',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#2563eb',
  },
  navButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  navButtonTextSecondary: {
    color: '#2563eb',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default HomeScreen;